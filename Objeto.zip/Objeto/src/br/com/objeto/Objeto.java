package br.com.objeto;

public class Objeto
{
	public static void main (String[]args) 
	{
		Pessoa homem = new Pessoa();
		
		// atribui valores aos atributos do objeto
		homem.idPessoa = 40028922;
		homem.nome = "Fernando";
		homem.idade = 51;
		homem.cidade = "Bras�lia";
		homem.email = "emailDoFernando@gmail.com";
		homem.genero = "Masculino";
		
		System.out.println("ID: " + homem.idPessoa);
		System.out.println("Nome: " + homem.nome);
		System.out.println("Idade: " + homem.idade);
		System.out.println("Cidade: " + homem.cidade);
		System.out.println("E-mail: " + homem.email);
		System.out.println("G�nero: " + homem.genero);
		System.out.println("----------------------------------------");
		homem.cumprimentar();
		
		
		
		
		
		
	}
}
