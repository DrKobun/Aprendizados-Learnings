package br.com.objeto;

public class Pessoa 
{
	public int idPessoa;
	public int idade;
	public String nome;
	public String email;
	public String cidade;
	public String genero;
	
	public void cumprimentar() 
	{
		System.out.println("Oi meu nome � " + this.nome + ".");
		System.out.println("Tenho " + this.idade + " anos" + ".");
		System.out.println("Sou de " + this.cidade + ".");
		System.out.println("Meu g�nero � " + this.genero + ".");
		System.out.println("Meu email � " + this.email);
		System.out.println("Meu ID: " + this.idPessoa + ".");
	}
	
}
