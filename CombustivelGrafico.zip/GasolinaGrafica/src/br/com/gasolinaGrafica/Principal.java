package br.com.gasolinaGrafica;

import javax.swing.JOptionPane;

public class Principal 
{
	public static void main(String[] args) 
	{
		Gasolina classe = new Gasolina();
		
		String gasolina;
		String etanol;
			
		gasolina = JOptionPane.showInputDialog("Informe o valor da Gasolina:");
		etanol = JOptionPane.showInputDialog("Informe o valor do etanol");
		
		gasolina = gasolina.replace(",", ".");
		etanol = etanol.replace(",", ".");
		
		classe.setGasolina(Double.parseDouble(gasolina));
		classe.setEtanol(Double.parseDouble(etanol));
		
		
		JOptionPane.showMessageDialog(null, classe.formula());
	}
}
