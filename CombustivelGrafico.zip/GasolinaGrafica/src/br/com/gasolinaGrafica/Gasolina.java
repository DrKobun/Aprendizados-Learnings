package br.com.gasolinaGrafica;

public class Gasolina
{
	private double etanol;
	private double gasolina;	
	

	public void setEtanol(double etanol)
	{
		this.etanol = etanol;
	}

	public void setGasolina(double gasolina) 
	{
		this.gasolina = gasolina;
	}

	public String formula() 
	{
		double resultado = (etanol / gasolina) * 100;
		
		if(resultado >= 70)
			return "Compensa Gasolina. \nResultado: " + String.format("%.2f", resultado) + "\nValor informado 'Gasolina: " + gasolina + "'." + "\nValor informado 'Etanol: " + etanol + "'.";
		else 
			return "Compensa Etanol. \nResultado: " + String.format("%.2f", resultado) + "\nValor informado 'Gasolina: " + gasolina + "'." + "\nValor informado 'Etanol: " + etanol + "'.";
	}
}
