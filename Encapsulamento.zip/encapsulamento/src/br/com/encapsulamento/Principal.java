package br.com.encapsulamento;

import java.util.Scanner;

public class Principal
{
	public static void main(String[] args) 
	{
		Pessoa humano = new Pessoa();
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Informe o nome:");
		humano.setNome(entrada.nextLine());
		System.out.println("Informe o cpf:");
		humano.setCpf(entrada.nextLine());
		System.out.println("Informe o email:");
		humano.setEmail(entrada.nextLine());
		System.out.println("Informe o telefone:");
		humano.setTelefone(entrada.nextLine());
		System.out.println("Informe o endere�o:");
		humano.setEndereco(entrada.nextLine());
		System.out.println("Informe o genero:");
		humano.setGenero(entrada.nextLine());
		System.out.println("Informe a profiss�o:");
		humano.setProfissao(entrada.nextLine());
		System.out.println("Informe a idade:");
		humano.setIdade(entrada.nextInt());
		System.out.println("Informe a altura:");
		humano.setAltura(entrada.nextDouble());
		System.out.println("Informe o peso:");
		humano.setPeso(entrada.nextDouble());
			
		System.out.println("Seu nome � " + humano.getNome());
		System.out.println("CPF: " + humano.getCpf());
		System.out.println("email: " + humano.getEmail());
		System.out.println("telefone: " + humano.getTelefone());
		System.out.println("endere�o: " + humano.getEndereco());
		System.out.println("genero: " + humano.getGenero());
		System.out.println("profiss�o: " + humano.getProfissao());
		System.out.println("idade: " + humano.getIdade());
		System.out.println("altura: " + humano.getAltura());
		System.out.println("peso: " + humano.getPeso());	
	}
}
