package br.com.uml;

import java.util.Scanner;

public class Principal
{

	public static void main(String[] args)
	{
		Pessoa humano = new Pessoa();		
		Scanner entrada = new Scanner(System.in);
		
		
		
		System.out.println("Informe o nome:");
		humano.setNome(entrada.nextLine());
		System.out.println("Informe o email:");
		humano.setEmail(entrada.nextLine());
		System.out.println("Informe a idade:");
		humano.setIdade(entrada.nextInt());
		System.out.println("Informe o peso:");
		humano.setPeso(entrada.nextDouble());
		System.out.println("Informe a altura:");
		humano.setAltura(entrada.nextDouble());
		
		
		System.out.println("Nome: " + humano.getNome());
		System.out.println("Email: " + humano.getEmail());
		System.out.println("Idade: " + humano.getIdade());
		System.out.println("Peso: " + humano.getPeso());
		System.out.println("Altura: " + humano.getAltura());
		System.out.println("IMC: " + humano.calcularIMC());
		System.out.println("Diagnostico: " + humano.retornarDiagnostico(humano.calcularIMC()));
		System.out.println("� maior de idade: " + humano.verificarIdade());
		
		
		
		
		
		
		
	}
}
