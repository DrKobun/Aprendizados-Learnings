package br.com.filmes;

public class Cliente
{
	String nome;
	int idade;
	
	public void apresentar() 
	{
		System.out.println("Ol� " + nome + " qual filme gostaria de assistir ?");		
	}
	public void filmes() 
	{
		System.out.println("Filmes dispon�veis: (selecione uma op��o para continuar)");
		System.out.println("[1] - Turma da M�nica: Li��es (Livre para todos os P�blicos)");
		System.out.println("[2] - Cora��o de Fogo (Livre para todos os P�blicos)");
		System.out.println("[3] - Sing 2 (Livre para todos os P�blicos)");
		System.out.println("[4] - Uncharted: Drake's Fortune (Para maiores de 12 anos)");
		System.out.println("[5] - Homem-Aranha: Sem Volta para Casa (Para maiores de 12 anos)");
		System.out.println("[6] - Case Comigo (Para maiores de 12 anos)");
		System.out.println("[7] - T� Ryca 2 (Para maiores de 12 anos)");
		System.out.println("[8] - Moonfall - Amea�a Lunar (Para maiores de 14 anos)");
		System.out.println("[9] - Morte no Nilo (Para maiores de 14 anos)");
		System.out.println("[10] - Eduardo e M�nica (Para maiores de 14 anos)");
		System.out.println("[11] - Exorcismo Sagrado (Para maiores de 16 anos)");
		System.out.println("[12] - A Jaula (Para maiores de 16 anos)");
	}
	
}
