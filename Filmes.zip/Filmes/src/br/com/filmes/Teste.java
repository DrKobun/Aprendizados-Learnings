package br.com.filmes;

import java.util.Scanner;

public class Teste 
{

	public static void main(String[] args) 
	{
		Cliente cliente = new Cliente();
		Scanner entrada = new Scanner(System.in);
		
		int escolha;
		
		
		System.out.println("Bem vindo! \n Infome seu nome para prosseguir:");
		cliente.nome = entrada.nextLine();
		System.out.println("Informe sua idade:");
		cliente.idade = entrada.nextInt();
		
		
		cliente.apresentar();
		cliente.filmes();

		escolha = entrada.nextInt();
		
		if(escolha == 13)
		{
			System.out.println("Fim do programa!");
		}
			
		
		
			switch(escolha) 
		{
			case 1:
				System.out.println("Filme livre para todos.");
				break;
			case 2:
				System.out.println("Filme livre para todos.");
				break;
			case 3: 
				System.out.println("Filme livre para todos.");
				break;
			case 4:
				if(cliente.idade < 12) 
				{
					System.out.println("Filme recomendado para maiores de 12 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");					
				} else 
					{
						System.out.println("Filme recomendado para maiores de 12 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
			case 5:
				if(cliente.idade < 12) 
				{
					System.out.println("Filme recomendado para maiores de 12 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");					
				} else 
					{
						System.out.println("Filme recomendado para maiores de 12 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
			case 6:
				if(cliente.idade < 12) 
				{
					System.out.println("Filme recomendado para maiores de 12 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");					
				} else 
					{
						System.out.println("Filme recomendado para maiores de 12 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
			case 7:
				if(cliente.idade < 12) 
				{
					System.out.println("Filme recomendado para maiores de 12 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");					
				} else 
					{
						System.out.println("Filme recomendado para maiores de 12 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
			case 8:
				if(cliente.idade < 14) 
				{
					System.out.println("Filme recomendado para maiores de 14 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");					
				} else 
					{
						System.out.println("Filme recomendado para maiores de 14 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
			case 9:
				if(cliente.idade < 14) 
				{
					System.out.println("Filme recomendado para maiores de 14 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");					
				} else 
					{
						System.out.println("Filme recomendado para maiores de 14 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
			case 10:
				if(cliente.idade < 14) 
				{
					System.out.println("Filme recomendado para maiores de 14 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");					
				} else 
					{
						System.out.println("Filme recomendado para maiores de 14 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
			case 11:
				if(cliente.idade < 16) 
				{
					System.out.println("Filme recomendado para maiores de 16 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");	
				} else 
					{
						System.out.println("Filme recomendado para maiores de 16 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
			case 12:
				if(cliente.idade < 16) 
				{
					System.out.println("Filme recomendado para maiores de 16 anos! \n Sua idade: " + cliente.idade + "\n Voc� n�o pode assistir esse filme!");					
				} else 
					{
						System.out.println("Filme recomendado para maiores de 16 anos! \n Sua idade : " + cliente.idade + "\n Voc� pode assistir esse filme!");
					}
				break;
		}
	}
}
