package br.com.gasolina;

import java.util.Scanner;

public class Combustivel 
{
	public static void main(String[] args) 
	{
		double gasolina;
		double etanol;
		double resultado;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Informe o valor do Etanol: ");
		etanol = entrada.nextDouble();
		System.out.println("Valor informado do Etanol: R$ " + etanol + "\n");
		
		
		System.out.println("Informe o valor da Gasolina: ");
		gasolina = entrada.nextDouble();
		System.out.println("Valor informado da Gasolina: R$ " + gasolina + "\n");
		
		resultado = (etanol / gasolina) * 100;
		
		if(resultado >= 70) 
		{
			System.out.println("*Compensa gasolina* " + resultado);
		} else 
		{
			System.out.println("*Compensa etanol* " + resultado);
		}
	}
}
