package br.com.calculadora;

public class Resultado 
{
	
	public int Somar(int x ,int y) 
	{
		return x + y;
	}
//----------------------------------------	
	public int Subtrair(int x ,int y) 
	{
		return x - y;
	}
//----------------------------------------		
	public int Multiplicar(int x ,int y) 
	{
		return x * y;
	}
//----------------------------------------		
	public double Dividir(int x ,int y) 
	{
		return x / y;
	}

}
