package br.com.calculadora;

import java.util.Scanner;

public class Calculadora 
{
	public static void main(String[] args) 
	{
		
		Scanner entrada = new Scanner(System.in);
		Resultado resultado = new Resultado();
		
		int x;
		int y;
		int operador;
		
		do 
		{
			System.out.println("Escolha uma op��o: ");
			System.out.println("1 = somar");
			System.out.println("2 = subtrair");
			System.out.println("3 = multiplicar ");
			System.out.println("4 = dividir");
			System.out.println("Digite 'sair' para encerrar");
			operador = entrada.nextInt();
			
			if(operador == 5) 
			{
				System.out.println("Programa encerrado!");
			}	else 
			{
				System.out.println("Informe o 1� n�mero:");
				x = entrada.nextInt();
				System.out.println("Informe o 2� n�mero:");
				y = entrada.nextInt();
				
				
				switch(operador)
				{
				case 1:
					System.out.println("Resultado: " + resultado.Somar(x, y) + "\n");
					break;
				case 2:
					System.out.println("Resultado: " + resultado.Subtrair(x, y) + "\n");
					break;
				case 3:
					System.out.println("Resultado: " + resultado.Multiplicar(x, y) + "\n");
					break;
				case 4:
					System.out.println("Resultado: " + resultado.Dividir(x, y) + "\n");
					break;
				default:
					System.out.println("Operador Inv�lido!");
					//break;
				}
			}
			
		} 
		while(operador != 5);
		
	}
}
