package br.com.imc;

import java.util.Scanner;

public class Teste
{

	public static void main(String[] args)
	{
		Scanner entrada = new Scanner(System.in);
		Metodo formula = new Metodo();
		
		double x;
		double y;

		
		System.out.println("Informe seu peso: ");
		x = entrada.nextDouble();
		System.out.println("Informe sua altura: ");
		y = entrada.nextDouble();
		
		System.out.println("IMC : " + formula.formula(x, y));
		
	}
}
