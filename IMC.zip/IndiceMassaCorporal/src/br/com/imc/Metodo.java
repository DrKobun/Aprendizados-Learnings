package br.com.imc;

public class Metodo
{
	 // IMC = Peso � (Altura � Altura)
	public double formula(double x, double y) 
	{
		double a = y * y;
		
		return x / a;
	}
	
}
