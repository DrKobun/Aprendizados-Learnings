package br.com.banco;

public class Usuario 
{
	String nome;
	double saldo;
	
	public void consultarSaldo() 
	{
		System.out.print(saldo + "\n");
	}
	
	public void telaInicial() 
	{
		System.out.println("Ol� " + nome + " oque deseja fazer ?");
		System.out.println("Digite: '1' para Sacar");
		System.out.println("Digite: '2' para Depositar");
		System.out.println("Digite: '3' para Verificar seu saldo");
		System.out.println("Digite: '4' para SAIR");
	}	
}
