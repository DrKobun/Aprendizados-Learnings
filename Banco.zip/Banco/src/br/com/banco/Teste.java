package br.com.banco;

import java.util.Scanner;

public class Teste
{
	public static void main(String[] args)
	{
		Usuario user = new Usuario();
		Scanner entrada = new Scanner(System.in);
		
		double valorDeposito;
		double valorSaque;
		int operador;
		
		System.out.println("Para come�ar digite seu nome: ");
		user.nome = entrada.nextLine();

		user.telaInicial();
		
		do
		{
			operador = entrada.nextInt();
			if(operador == 4)
			{
				System.out.println("Programa encerrado!");
			}
			
			switch(operador) 
			{
			
			case 1:
				if(user.saldo == 0) 
				{
					System.out.println("N�o h� saldo dispon�vel em sua conta!");
					user.telaInicial();
					break;
				}
				
				System.out.println("Qual valor voc� gostaria de sacar ? ");
				valorSaque = entrada.nextDouble();
				
				if(valorSaque <= 0)
				{
					System.out.println("Valor Inv�lido!");
				} 
				
				if(valorSaque > user.saldo)
				{				
					System.out.println("Valor informado � maior que seu saldo!");
				}
				
				if(valorSaque < user.saldo) 
				{
					System.out.println("Valor sacado: " + valorSaque);
					user.saldo = user.saldo - valorSaque;
					System.out.println("Saldo atual: " + user.saldo);
				}
				user.telaInicial();
				break;
			case 2: 
				System.out.println("Qual valor voc� gostaria de depositar ? ");
				valorDeposito = entrada.nextDouble();
				if(valorDeposito > 0) 
				{
					user.saldo += valorDeposito;
					System.out.println("Valor depositado: " + valorDeposito);
						
				} else 
					{
						System.out.println("Valor inv�lido!");
					}
				user.telaInicial();
				break;
			case 3:
				System.out.println("Seu saldo atual: " + user.saldo);
				user.telaInicial();
				break;
				default:
					break;
			}	
		} while(operador != 4);
	
	}
}
