package br.com.equacao;

import javax.swing.JOptionPane;

public class Principal 
{	
	public static void main(String[] args)
	{
		Equacao classe = new Equacao();
		
		String letraA;
		String letraB;
		
		letraA = JOptionPane.showInputDialog("Informe o valor de A:");
		letraB = JOptionPane.showInputDialog("Informe o valor de B:");
		
		classe.setA(Double.parseDouble(letraA));
		classe.setB(Double.parseDouble(letraB));
		JOptionPane.showMessageDialog(null, classe.equacao());
	}
}
