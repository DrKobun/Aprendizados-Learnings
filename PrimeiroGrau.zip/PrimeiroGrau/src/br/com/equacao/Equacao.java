package br.com.equacao;

public class Equacao 
{
	private double a;
	private double b;
	
	public void setA(double a)
	{
		this.a = a;
	}

	public void setB(double b)
	{
		this.b = b;
	}
	
	public String equacao()
	{
		double x;
		x = -b / a;
		
		if(a != 0) 
		{
			return "A resposta �: \n x = " + x;	
		} else
		{
			return "o valor de 'a' n�o pode ser igual a 0.";
		}
	}
}
