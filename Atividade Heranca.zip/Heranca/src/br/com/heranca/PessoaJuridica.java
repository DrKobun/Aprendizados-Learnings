package br.com.heranca;

public class PessoaJuridica extends Pessoa{
	// Atributos
	public String razaoSocial;
	public String nomeFantasia;
	public String CNPJ;
	
	// Polimorfismo
	public void informarDados() {
		System.out.println("Somos da empresa " + this.nomeFantasia + ".");
		super.informarDados();
	}
}
