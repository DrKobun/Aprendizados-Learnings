package br.com.heranca;

public class PessoaFisica extends Pessoa {
	// Atributos
	public String nome;
	public String profissao;
	public String genero;
	
	// Polimorfismo
	public void informarDados() 
	{
		System.out.println("Ol�, meu nome � " + this.nome + ".");
		System.out.println("Trabalho como " + this.profissao + ".");
		super.informarDados();
	}
}
