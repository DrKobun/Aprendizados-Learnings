package br.com.heranca;

public class Pessoa {
	// Atributos
	public int idPessoa;
	public String endereco;
	public String telefone;
	public String email;
	
	// M�todo
	public void informarDados() {
		System.out.println("Meu ID � " + this.idPessoa + ".");
		System.out.println("Meu endere�o � " + this.endereco + ".");
		System.out.println("Meu telefone � " + this.telefone + ".");
		System.out.println("Meu e-mail � " + this.email + ".");
	}
}
