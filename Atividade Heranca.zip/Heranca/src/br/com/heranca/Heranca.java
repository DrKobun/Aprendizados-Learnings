package br.com.heranca;

import java.util.Scanner;

public class Heranca 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		// Instancia os objetos
		Scanner leia = new Scanner(System.in);
		PessoaFisica humano = new PessoaFisica();
		PessoaJuridica empresa = new PessoaJuridica();
		
		// Declara��o de vari�veis
		int idPessoa;
		
		// Entrada de dados da pessoa f�sica
		System.out.println("Informe o nome da pessoa:");
		humano.nome = leia.nextLine();
		System.out.println("Informe a profiss�o:");
		humano.profissao = leia.nextLine();
		System.out.println("Informe o g�nero:");
		humano.genero = leia.nextLine();
		System.out.println("Informe o e-mail:");
		humano.email = leia.nextLine();
		System.out.println("Informe o telefone:");
		humano.telefone = leia.nextLine();
		System.out.println("Informe o endere�o:");
		humano.endereco = leia.nextLine();
		
		// Entrada de dados da empresa
		System.out.println("Informe o nome fantasia da empresa:");
		empresa.nomeFantasia = leia.nextLine();
		System.out.println("Informe a raz�o social da empresa:");
		empresa.razaoSocial = leia.nextLine();
		System.out.println("Informe o CNPJ da empresa:");
		empresa.CNPJ = leia.nextLine();
		System.out.println("Informe o e-mail da empresa:");
		empresa.email = leia.nextLine();
		System.out.println("Informe o telefone da empresa:");
		empresa.telefone = leia.nextLine();
		System.out.println("Informe o endere�o da empresa:");
		empresa.endereco = leia.nextLine();
		
		// Atribui id aos objetos
		humano.idPessoa = 1;
		empresa.idPessoa = 2;
		
		// Sa�da de dados
		humano.informarDados();
		empresa.informarDados();
	}

}
