package atividade07;

public class Veiculo 
{

	String fabricante;
	String modelo;
	int ano;
	String cor;
	String placa;
	
	public void apresentarCarro() 
	{
		System.out.println("Caracter�sticas do carro:");
		System.out.println("Fabricante: " + this.fabricante);
		System.out.println("Modelo: " + this.modelo);
		System.out.println("Ano: " + this.ano);
		System.out.println("Cor: " + this.cor);
		System.out.println("Placa: " + this.placa);
	}
}
