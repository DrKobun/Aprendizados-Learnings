package atividade07;

public class Teste
{
	public static void main(String[] args)
	{
		Veiculo carro = new Veiculo();
		
		
		carro.fabricante = "General Motors";
		carro.modelo = "Chevrolet Corvette C8 2022";
		carro.ano = 2022;
		carro.cor = "Amarelo";
		carro.placa = "CVL - 0727";
		carro.apresentarCarro();
		
	}
}
